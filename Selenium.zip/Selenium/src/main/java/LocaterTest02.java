import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LocaterTest02 {
	
	
	public static void main(String[] args) {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("http://www.yahoo.com");
		
		WebElement textbox = driver.findElement(By.id("ybar-sbq"));
		textbox.sendKeys("panda");
	}

}
