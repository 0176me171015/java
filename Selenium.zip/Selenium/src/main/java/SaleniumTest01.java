import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SaleniumTest01{
	
	public static void main(String[] args) {
		
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		WebDriver driver1 = new EdgeDriver();
		
		//passing the value that we want to pass
		//means where you wan to open
		driver.get("http://www.google.com");
		
//		driver1.get("http://www.youtube.com");
	}

}
