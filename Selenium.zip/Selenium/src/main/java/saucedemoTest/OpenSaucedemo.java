package saucedemoTest;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OpenSaucedemo {
	
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		
		Thread th = new Thread();
		//normal accessing element
//		WebElement textbox = driver.findElement(By.id("user-name"));
//		WebElement textpass = driver.findElement(By.id("password"));
//		WebElement button = driver.findElement(By.id("login-button"));
//		textbox.sendKeys("chandu");
//		textpass.sendKeys("chandu@123");
//		button.click();
		
		
		ArrayList <String> l = new ArrayList();
		l.add("standard_user");
		//l.add("locked_out_user");
		l.add("problem_user");
		l.add("amey");
//		l.add("");
//		l.add("");
		
		driver.get("https://www.saucedemo.com/");
		Iterator i = l.listIterator();
		
		while(i.hasNext()) {
			driver.get("https://www.saucedemo.com/");			
			
			WebElement textbox = driver.findElement(By.id("user-name"));
			textbox.sendKeys((String)i.next());
			
			WebElement textpass = driver.findElement(By.id("password"));
			textpass.sendKeys("secret_sauce");
			
			WebElement button = driver.findElement(By.id("login-button"));
			button.click();
			
			
//			// Assuming the error message is in an h3 tag under a certain div
//						WebElement errorMessage = driver
//								.findElement(By.xpath("//*[@id='login_button_container']/div/form/div[3]/h3"));
//						System.out.println("Error Message Text: " + errorMessage.getText());

//						// Check if the error message is as expected
//						if (errorMessage.getText().equals("Epic sadface: Username is required")) {
//							System.out.println("Correct password text");
//						} else {
//							System.out.println("Wrong password text");
//						}
		}
		
	}
}
