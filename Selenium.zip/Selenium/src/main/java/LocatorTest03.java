import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LocatorTest03 {
	
	public static void main(String[] args) {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		
//		driver.get("https://jqueryui.com/droppable/");
		driver.get("https://google.com");
		driver.manage().window().maximize();
		
		
		// full path
 		 //html/body/ntp-app//div/div[2]/ntp-realbox//div/input  
		//driver.findElement(By.xpath("html/body/ntp-app//div/div[2]/ntp-realbox//div/input  full path"));
		
		
		//relative full path
		WebElement textbox = driver.findElement(By.xpath("//*[@id=\"APjFqb\"]"));
		
	}

}
