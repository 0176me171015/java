import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LocaterTest {

		public static void main(String[] args) {
			
			WebDriverManager.edgedriver().setup();
			WebDriver driver = new EdgeDriver();
//			WebDriver driver1 = new EdgeDriver();
			driver.get("http://www.google.com");
			
			WebElement textbox = driver.findElement(By.name("q"));
			textbox.sendKeys("sunny");
			
		}
}
